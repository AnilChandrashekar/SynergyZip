package com.synergy.synergytool.model;

import java.util.Date;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import com.fasterxml.jackson.annotation.JsonProperty;

/*
 * Please note that this class is annotated with @Document annotation
 * @Document identifies a domain object to be persisted to MongoDB.
 *  */
@Document
public class AccountInfo {
	
	@Id
	int accountId;
	@JsonProperty("accName")
	String accountName;
	@JsonProperty("selectedServiceLinesID")
	String selServiceLineId;
	@JsonProperty("selectedFunctionID")
	String selFunctionId;
	@JsonProperty("selectedEngModelID")
	String selEngModelId;
	@JsonProperty("selectedDelMethodID")
	String selDelMethodId;
	@JsonProperty("selectedAutomationID")
	String selAutomationId;
	@JsonProperty("competetionID")
	String completionId;
	
	public String getCompletionId() {
		return completionId;
	}
	public void setCompletionId(String completionId) {
		this.completionId = completionId;
	}
	Date addedTimeStamp;


	public int getAccountId() {
		return accountId;
	}
	public void setAccountId(int accountId) {
		this.accountId = accountId;
	}
	public String getAccountName() {
		return accountName;
	}
	public void setAccountName(String accountName) {
		this.accountName = accountName;
	}
	public String getSelServiceLineId() {
		return selServiceLineId;
	}
	public void setSelServiceLineId(String selServiceLineId) {
		this.selServiceLineId = selServiceLineId;
	}
	public String getSelFunctionId() {
		return selFunctionId;
	}
	public void setSelFunctionId(String selFunctionId) {
		this.selFunctionId = selFunctionId;
	}
	public String getSelEngModelId() {
		return selEngModelId;
	}
	public void setSelEngModelId(String selEngModelId) {
		this.selEngModelId = selEngModelId;
	}
	public String getSelDelMethodId() {
		return selDelMethodId;
	}
	public void setSelDelMethodId(String selDelMethodId) {
		this.selDelMethodId = selDelMethodId;
	}
	public String getSelAutomationId() {
		return selAutomationId;
	}
	public void setSelAutomationId(String selAutomationId) {
		this.selAutomationId = selAutomationId;
	}
	
	public Date getAddedTimeStamp() {
		return addedTimeStamp;
	}
	public void setAddedTimeStamp(Date addedTimeStamp) {
		this.addedTimeStamp = addedTimeStamp;
	}
	
}
