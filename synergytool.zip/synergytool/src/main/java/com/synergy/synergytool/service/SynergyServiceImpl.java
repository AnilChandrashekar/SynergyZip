package com.synergy.synergytool.service;

import java.util.List;
import java.util.NoSuchElementException;

import org.springframework.stereotype.Service;
import com.synergy.synergytool.model.AccountInfo;
import com.synergy.synergytool.repository.SynergyRepository;

@Service
public class SynergyServiceImpl implements SynergyService {

	
	private SynergyRepository synergyRepository;
	
	public SynergyServiceImpl(SynergyRepository synergyRepository)
	{
		this.synergyRepository = synergyRepository;
	}
	
	public AccountInfo createAccountInfo(AccountInfo accInfo) {

		AccountInfo accInfoCreate =  synergyRepository.insert(accInfo);
		
		if(accInfoCreate!=null)
		{
			return accInfoCreate;
		}
		return null;
	}

	
	public List<AccountInfo> getAllAccountInfo() {

		return synergyRepository.findAll();
	}
	

}
