package com.synergy.synergytool.controller;

import java.util.Date;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;
import com.synergy.synergytool.model.AccountInfo;
import com.synergy.synergytool.service.NextSequenceService;
import com.synergy.synergytool.service.SynergyService;

@RestController
public class SynergyController {
	
private SynergyService synergyService;
	
	public SynergyController(SynergyService synergyService) {
			this.synergyService = synergyService;
	}
	
	@Autowired
	private NextSequenceService nextSequenceService;
	
	@PostMapping("/api/v1/accInfo")
	public ResponseEntity<?> createCategory(@RequestBody List<AccountInfo> accountInfoList) {
		HttpHeaders headers = new HttpHeaders();
		try {
			
			if(accountInfoList!=null && !accountInfoList.isEmpty())
			{
				accountInfoList.forEach(accountInfo->{
					accountInfo.setAccountId(nextSequenceService.getNextSequence("customSequences"));
					accountInfo.setAddedTimeStamp(new Date());
					synergyService.createAccountInfo(accountInfo);
				});
				return new ResponseEntity<>(headers, HttpStatus.CREATED);
			}
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(headers, HttpStatus.CONFLICT);
		}
		return new ResponseEntity<>(headers, HttpStatus.CONFLICT);
	}
	
	@GetMapping("/api/v1/accInfo")
	public ResponseEntity<?> getAllAccountInfo() {
		System.out.println("getAllAccountInfo START");
		HttpHeaders headers = new HttpHeaders();
		try {
			
		List<AccountInfo> accInfoList =	synergyService.getAllAccountInfo();
		System.out.println("accInfoList: "+accInfoList);
			if(accInfoList!=null)
				{
				return new ResponseEntity<List<AccountInfo>>(accInfoList, HttpStatus.OK);
			}
			//System.out.println("accInfoList: "+accInfoList);
		} catch (Exception e) {
			e.printStackTrace();
			return new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
		}
		return new ResponseEntity<>(headers, HttpStatus.NOT_FOUND);
	}

}
