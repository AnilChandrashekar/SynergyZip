package com.synergy.synergytool.service;


import java.util.List;
import com.synergy.synergytool.model.AccountInfo;

public interface SynergyService {
	

    AccountInfo createAccountInfo(AccountInfo accountInfo) ;

    List<AccountInfo> getAllAccountInfo();

}
